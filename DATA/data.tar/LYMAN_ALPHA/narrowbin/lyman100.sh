#! /bin/csh -f
#
cp faruv_Teff4500K.pdat_lyman100 faruv_Teff4500K.pdat
cp faruv_Teff5000K.pdat_lyman100 faruv_Teff5000K.pdat
cp faruv_Teff5500K.pdat_lyman100 faruv_Teff5500K.pdat
cp faruv_Teff5750K.pdat_lyman100 faruv_Teff5750K.pdat
cp faruv_Teff6000K.pdat_lyman100 faruv_Teff6000K.pdat
cp faruv_Teff6500K.pdat_lyman100 faruv_Teff6500K.pdat
cp faruv_Teff6750K.pdat_lyman100 faruv_Teff6750K.pdat
cp faruv_Teff7000K.pdat_lyman100 faruv_Teff7000K.pdat
cp faruv_K2V.pdat_lyman100 faruv_K2V.pdat
cp faruv_G2V.pdat_lyman100 faruv_G2V.pdat
cp faruv_F2V.pdat_lyman100 faruv_F2V.pdat
