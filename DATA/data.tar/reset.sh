#! /bin/csh -f
#
#RESET TO ORIGINAL
cp Teff7000K_photo.pdat_original Teff7000K_photo.pdat
cp Teff7000K_surf.pdat_original Teff7000K_surf.pdat
cp faruv_Teff7000K.pdat_original faruv_Teff7000K.pdat
#
cp Teff6750K_photo.pdat_original Teff6750K_photo.pdat
cp Teff6750K_surf.pdat_original Teff6750K_surf.pdat
cp faruv_Teff6750K.pdat_original faruv_Teff6750K.pdat
#
cp Teff6500K_photo.pdat_original Teff6500K_photo.pdat
cp Teff6500K_surf.pdat_original Teff6500K_surf.pdat
cp faruv_Teff6500K.pdat_original faruv_Teff6500K.pdat
#
cp Teff6250K_photo.pdat_original Teff6250K_photo.pdat
cp Teff6250K_surf.pdat_original Teff6250K_surf.pdat
cp faruv_Teff6250K.pdat_original faruv_Teff6250K.pdat
#
cp Teff6000K_photo.pdat_original Teff6000K_photo.pdat
cp Teff6000K_surf.pdat_original Teff6000K_surf.pdat
cp faruv_Teff6000K.pdat_original faruv_Teff6000K.pdat
#
cp Teff5750K_photo.pdat_original Teff5750K_photo.pdat
cp Teff5750K_surf.pdat_original Teff5750K_surf.pdat
cp faruv_Teff5750K.pdat_original faruv_Teff5750K.pdat
#
cp Teff5500K_photo.pdat_original Teff5500K_photo.pdat
cp Teff5500K_surf.pdat_original Teff5500K_surf.pdat
cp faruv_Teff5500K.pdat_original faruv_Teff5500K.pdat
#
cp Teff5250K_photo.pdat_original Teff5250K_photo.pdat
cp Teff5250K_surf.pdat_original Teff5250K_surf.pdat
cp faruv_Teff5250K.pdat_original faruv_Teff5250K.pdat
#
cp Teff5000K_photo.pdat_original Teff5000K_photo.pdat
cp Teff5000K_surf.pdat_original Teff5000K_surf.pdat
cp faruv_Teff5000K.pdat_original faruv_Teff5000K.pdat
#
cp Teff4750K_photo.pdat_original Teff4750K_photo.pdat
cp Teff4750K_surf.pdat_original Teff4750K_surf.pdat
cp faruv_Teff4750K.pdat_original faruv_Teff4750K.pdat
#
cp Teff4500K_photo.pdat_original Teff4500K_photo.pdat
cp Teff4500K_surf.pdat_original Teff4500K_surf.pdat
cp faruv_Teff4500K.pdat_original faruv_Teff4500K.pdat
#
cp Teff4250K_photo.pdat_original Teff4250K_photo.pdat
cp Teff4250K_surf.pdat_original Teff4250K_surf.pdat
cp faruv_Teff4250K.pdat_original faruv_Teff4250K.pdat
